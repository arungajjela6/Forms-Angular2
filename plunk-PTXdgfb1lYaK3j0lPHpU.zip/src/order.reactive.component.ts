import { Component,OnInit} from '@angular/core';
import {FormBuilder,FormGroup,Validators} from '@angular/forms';
import {Order} from './order';

@Component({
  selector: 'my-app',
  templateUrl: './src/order.reactive.component.html'
})
export class App implements OnInit{
  
    orderForm:FormGroup;
   
     order = new Order(324,"Dell",1,500.00,500.00);
     
     formErrors={
      'id':'';
      'itemname':'';
      'quantity':'';
      'price':'';
      'amount':'';
     };
     
     constructor(private fb: FormBuilder){}
     
     
     ngOnInit():void{
       this.buildForm();
     }
     
     buildForm(): void{
       
       this.orderForm = this.fb.group({
          'id':[this.order.id,[
                      Validators.required,
                      Validators.minLength(3),
                      Validators.maxLength(4),
                      Validators.pattern("^[0-9]*$")
                      ]],
          'itemname':[this.order.itemname,[
                      Validators.required,
                      Validators.minLength(4),
                      Validators.maxLength(10)
                      ]],
          'quantity':[this.order.quantity],
          'price':[this.order.price],
          'amount':[this.order.amount]
          
       });
       
       this.orderForm.valueChanges.subscribe(data => this.onValueChanged(data));
       
     }
     
  onValueChanged(data?:any){
    
    if(!this.orderForm){
      return;
    }
    
    const idControl = this.orderForm.get('id');
    
    if(idControl && idControl.dirty && !idControl.valid){
      
        for(const key in idControl.errors){
          
          if(key == 'required'){
             this.formErrors['id']='ID is required';
          }
          
          if(key == 'minlength'){
             this.formErrors['id']='ID should be minimum 3 digits';
          }
          
          if(key == 'maxlength'){
             this.formErrors['id']='ID cannot be more than 4 digits';
          }
          if(key == 'pattern'){
             this.formErrors['id']='ID must be a number';
          }
        }
      
    }
    
    const nameControl = this.orderForm.get('itemname');
    
    if(nameControl && nameControl.dirty && !nameControl.valid){
      
        for(const key in nameControl.errors){
          
          if(key == 'required'){
             this.formErrors['itemname']='Itemname is required';
          }
          
          if(key == 'minlength'){
             this.formErrors['itemname']='Itemname should be minimum 4 characters';
          }
          
          if(key == 'maxlength'){
             this.formErrors['itemname']='Itemname cannot be more than 10 characters';
          }
        }
      
    }  
      
    }
    
    
  }
    
    
  }
  
