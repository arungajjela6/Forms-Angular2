export class Order{
  
  constructor(public id:number,public itemname:string,public quantity:number,public price:number,public amount:number){
}
  
}