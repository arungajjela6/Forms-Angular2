import {Component, NgModule, VERSION} from '@angular/core';
import {NgForm} from '@angular/forms'
import {Order} from './order.ts'
@Component({
  selector: 'my-app',
  templateUrl: './src/register.form.html'
})
export class App {
 order = new Order(123,"Dell Laptop",1,500.00,500.00);
}